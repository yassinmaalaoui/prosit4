package tn.esprit.gestionzoo.entities;

public class Animal {
    private String family;
    String name;
    private int age;
    private boolean isMammal;

    public Animal(String family, String name, int age, boolean isMammal) {
        this.family = family;
        this.name = name;
        this.age=age;
        this.isMammal = isMammal;
    }

    public void setAge(int age) {
        if (age<0){
            System.out.println("l'age ne peut etre pas negative");
        }else{
            this.age=age;
        }
    }

    public void setName(String name) {
        if (name==null ||name.isEmpty()){
            System.out.println("entrer un nom pour l'animal");

        }else {
            this.name=name;
        }
    }

    @Override
    public String toString() {
        return "tn.esprit.gestionzoo.entities.Animal [Famille: " + family + ", Nom: " + name + ", Âge: " + age + ", Mammifère: " + isMammal + "]";
    }
}